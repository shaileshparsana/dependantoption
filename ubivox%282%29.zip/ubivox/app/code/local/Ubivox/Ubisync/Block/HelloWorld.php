<?php
class Ubivox_Ubisync_Block_HelloWorld extends Mage_Core_Block_Template
{
    public $ubivox_message = "";

    protected function _toHtml()
    {
        return "> ".$this->ubivox_message;
    }
}