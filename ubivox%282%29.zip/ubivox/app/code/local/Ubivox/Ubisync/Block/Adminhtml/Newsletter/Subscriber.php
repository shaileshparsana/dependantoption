<?php

class Ubivox_Ubisync_Block_Adminhtml_Newsletter_Subscriber extends Mage_Adminhtml_Block_Newsletter_Subscriber
{ 

    public function _toHtml() 
    {

        
        $inject_button = '
	<table cellspacing="0" style="width: 100%">
		<tr>
			<td align="right">
				<button  type="button" class="scalable" onclick="window.location=\''. $this->getUrl('ubisync/index/index/') .'\'" style="">
					<span>Ubivox Batch Upload</span>
				</button>
			</td>
		</tr>
	</table>        
        ';

        $notify = "";
        if(array_key_exists("ubivox_notify", $_SESSION)) {
            $notify = '
        <script type="text/javascript">
            alert("'.$_SESSION["ubivox_notify"].'");
        </script>';
            unset($_SESSION['ubivox_notify']);
        }

        $_par = parent::_toHtml();
        return $inject_button.$_par.$notify;
    }
}