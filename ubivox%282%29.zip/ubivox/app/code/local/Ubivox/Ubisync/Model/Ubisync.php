<?

class Ubivox_Ubisync_Model_Ubisync extends Varien_Object
{   

    public function getXmlConfiguration() 
    {
        return Mage::getStoreConfig('ubisync');
        
    }
    public function getUsername() 
    {
        //$conf = $this->getXmlConfiguration();
        //$conf
    }
    public function getPassword()
    {
        //$this->getXmlConfiguration()["credentials"]["ubivox_password"];
    }
    public function getApiConnection() 
    {
        // Retrieve Connection values
        $conf_values   = Mage::getStoreConfig('ubisync');
        var_dump($conf_values);
        $credentials   = $conf_values["credentials"];
        $username      = $credentials["ubivox_username"];
        $password      = $credentials["ubivox_password"];
        $url           = $credentials["ubivox_url"];
        
        try {
            $http = new Zend_Http_Client($credentials["ubivox_url"], array('keepalive'=>true));
            $http->setAuth($credentials["ubivox_username"], $credentials["ubivox_password"], Zend_Http_Client::AUTH_BASIC);            
            $client = new Zend_XmlRpc_Client($credentials["ubivox_url"], $http);        
            return $client;
        } catch(Exception $e) {
            throw $e;
        }

    }
    public function subscribe($email)
    {  
        Mage::getStoreConfig('ubisync');
        $configuration = $conf_values["configuration"];
        $listid        = $configuration["ubivox_listid"];
        $errormail     = $configuration["ubivox_errormail"];

        $client = $this->getApiConnection();

        $client->call('ubivox.create_subscription', array($listid));
        
    }
}
?>