<?php

require("lib/Zend/Mail/Transport/Smtp.php");

class Ubivox_Ubisync_Model_Newsletter_Subscriber extends Mage_Newsletter_Model_Subscriber
{
    private function getRPCClient()
    {
        $conf_values   = Mage::getStoreConfig('ubisync');
        $credentials   = $conf_values["credentials"];

        $username      = $credentials["ubivox_username"];
        $password      = $credentials["ubivox_password"];
        $url           = $credentials["ubivox_url"];

        $http = new Zend_Http_Client($url, array('keepalive'=>true));
        $http->setAuth($username, $password, Zend_Http_Client::AUTH_BASIC);            
        $client = new Zend_XmlRpc_Client($url, $http);        
        
        return $client;
    }

    public function subscribe($email) 
    {   
        $this->loadByEmail($email);
        
        $customer = Mage::getModel('customer/customer')
            ->setWebsiteId(Mage::app()->getStore()->getWebsiteId())
            ->loadByEmail($email);

        $conf_values   = Mage::getStoreConfig('ubisync',Mage::app()->getRequest()->getParam('store'));
        $credentials   = $conf_values["credentials"];
        $username      = $credentials["ubivox_username"];
        $password      = $credentials["ubivox_password"];
        $url           = $credentials["ubivox_url"];

        $storeID = Mage::app()->getStore()->getWebsiteId();
                
        try {
            $http = new Zend_Http_Client($url, array('keepalive'=>true));
            $http->setAuth($username, $password, Zend_Http_Client::AUTH_BASIC);            
            $client = new Zend_XmlRpc_Client($url, $http);        

            $configuration = $conf_values["configuration"];
            $listid        = $configuration["ubivox_listid"];
            $errormail     = $configuration["ubivox_errormail"];

            $return = $client->call('ubivox.create_subscription_with_data', array($email, $listid, "", array('store_'.$storeID => 'Ja')));
        } catch(Zend_XmlRpc_Client_HttpException $e) {
            $this->send_errormail($errormail, "An connection error occured when trying to synchronize a new subscriber $email to ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //throw $e;
        } catch(Zend_XmlRpc_Client_FaultException $e) {
            switch($e->getCode()) {
            case 1003: // Allready subscribed on this list in ubivox
                break;
            case 2001: // Invalid mailing list
                $this->send_errormail($errormail, "An error occured when trying to create newsletter subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
                //throw $e;
                break;
            case 1001: // E-mail address is invalid
                $this->send_errormail($errormail, "An error occured when trying to create a newsletter subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
                //throw $e;
                break;                
            }
        } catch(Exception $e) {
            $this->send_errormail($errormail, "An !unknown! error occured when trying to create a newsletter subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");                       
            //throw $e;
        }
        
        $this->setSubscriberStatus(self::STATUS_SUBSCRIBED);
        
        $test = parent::subscribe($email);
                
        return $this->getStatus();
    }

    public function delete() 
    {
        $email = $this->getEmail();
        $customer = Mage::getModel('newsletter/subscriber')->loadByEmail($email);

        $conf_values   = Mage::getStoreConfig('ubisync',$customer->_data['store_id']);
        $credentials   = $conf_values["credentials"];
        $username      = $credentials["ubivox_username"];
        $password      = $credentials["ubivox_password"];
        $url           = $credentials["ubivox_url"];

        try {
            $http = new Zend_Http_Client($url, array('keepalive'=>true));
            $http->setAuth($username, $password, Zend_Http_Client::AUTH_BASIC);
            $client = new Zend_XmlRpc_Client($url, $http);

            $configuration = $conf_values["configuration"];
            $listid        = $configuration["ubivox_listid"];
            $errormail     = $configuration["ubivox_errormail"];

            $client->call("ubivox.cancel_subscription", array($email, $listid));
        } catch(Zend_XmlRpc_Client_HttpException $e) {
            $this->send_errormail($errormail, "An connection error occured when trying to delete subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //            throw $e;
        } catch(Exception $e) {                       
            $this->send_errormail($errormail, "An !unknown! error occured when trying to delete subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //throw $e;
        }

        return parent::delete();
    }

    public function unsubscribe()
    {
        $email = $this->getEmail();
        $customer = Mage::getModel('newsletter/subscriber')->loadByEmail($email);

        $conf_values   = Mage::getStoreConfig('ubisync',$customer->_data['store_id']);
        $credentials   = $conf_values["credentials"];
        $username      = $credentials["ubivox_username"];
        $password      = $credentials["ubivox_password"];
        $url           = $credentials["ubivox_url"];

        try {
            $http = new Zend_Http_Client($url, array('keepalive'=>true));
            $http->setAuth($username, $password, Zend_Http_Client::AUTH_BASIC);            
            $client = new Zend_XmlRpc_Client($url, $http);        

            $configuration = $conf_values["configuration"];
            $listid        = $configuration["ubivox_listid"];
            $errormail     = $configuration["ubivox_errormail"];

            $return = $client->call('ubivox.cancel_subscription', array($email, $listid));
        } catch(Zend_XmlRpc_Client_HttpException $e) {
            $this->send_errormail($errormail, "An connection error occured when trying to unsubcribe recipient $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //throw $e;

        } catch(Exception $e) {                       
            $this->send_errormail($errormail, "An !unknown! error occured when trying to unsubcribe recipient $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //throw $e;
        }
        
        $this->setSubscriberStatus(self::STATUS_UNSUBSCRIBED);
        
        return parent::unsubscribe($email);
    }

    public function subscribeCustomer($customer) 
    {
        $this->loadByCustomer($customer);
        
        if($customer->hasIsSubscribed()) {
            $status = $customer->getIsSubscribed() ? self::STATUS_SUBSCRIBED : self::STATUS_UNSUBSCRIBED;
        } else {
            $status = ($this->getStatus() == self::STATUS_NOT_ACTIVE ? self::STATUS_UNSUBSCRIBED : $this->getStatus());
        }
        if($status != $this->getStatus()) {
            $this->setIsStatusChanged(true);
        }

        $this->setStatus($status);

        if(!$this->getId()) {
            $this->setStoreId($customer->getStoreId())
                ->setCustomerId($customer->getId())
                ->setEmail($customer->getEmail());
        } else {
            $this->setEmail($customer->getEmail());
        }


        $this->save();
        
        if($customer->getIsSubscribed()) {
            try {
                $this->sync_ubivox($customer->getEmail());
            } catch(Exception $e) {
                //die("<pre>{$e}</pre>");
		$this->send_errormail($errormail, "An !unknown! error occured when trying to subscribeCustomer $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            }
        }
        $sendSubscription = $customer->getData('sendSubscription');
        if (is_null($sendSubscription) xor $sendSubscription) {
            if ($this->getIsStatusChanged() && $status == self::STATUS_UNSUBSCRIBED) {
                $this->sendUnsubscriptionEmail();
            } elseif ($this->getIsStatusChanged() && $status == self::STATUS_SUBSCRIBED) {
                $this->sendConfirmationSuccessEmail();
            }
        }

        return $this;
    }
    private function sync_ubivox($email)
    {
        $conf_values   = Mage::getStoreConfig('ubisync');
        $credentials   = $conf_values["credentials"];
        $username      = $credentials["ubivox_username"];
        $password      = $credentials["ubivox_password"];
        $url           = $credentials["ubivox_url"];

        $storeID = Mage::app()->getStore()->getWebsiteId();

        try {
            $http = new Zend_Http_Client($url, array('keepalive'=>true));
            $http->setAuth($username, $password, Zend_Http_Client::AUTH_BASIC);            
            $client = new Zend_XmlRpc_Client($url, $http);        

            $configuration = $conf_values["configuration"];
            $listid        = $configuration["ubivox_listid"];
            $errormail     = $configuration["ubivox_errormail"];
            $return = $client->call('ubivox.create_subscription_with_data', array($email, $listid, "", array('store_'.$storeID => 'Ja')));
            
        } catch(Zend_XmlRpc_Client_HttpException $e) {
            $this->send_errormail($errormail, "An connection error occured when creating subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //throw $e;

        } catch(Zend_XmlRpc_Client_FaultException $e) {
            switch($e->getCode()) {
            case 1003: // Allready subscribed on this list in ubivox
                break;
            case 2001: // Invalid mailing list
                $this->send_errormail($errormail, "An error occured when creating subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
                //throw $e;
                break;
            case 1001: // E-mail address is invalid
                $this->send_errormail($errormail, "An error occured when creating subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
                //throw $e;
                break;                
            }
        } catch(Exception $e) {                       
            $this->send_errormail($errormail, "An unknown error occured when creating subscriber $email in ubivox.\n\nCode: ".$e->getCode()."\nMessage: ".$e->getMessage()."\n\n{$e}");
            //throw $e;
        }
    }
    private function send_errormail($errormail, $message) {
        try {
            $mail = new Zend_Mail();
            $mail->setBodyText($message);
            $mail->setSubject("Ubivox/Magento Plugin error.");
            $mail->addTo($errormail);
            $mail->setFrom($errormail, "Magento");        

            $transport = new Zend_Mail_Transport_Smtp();
            $mail->send($transport);
        } catch(Exception $e)
              {
                  //throw $e;
              }
        
    }
}
?>
