<?


class Ubivox_Ubisync_Model_Listids 
{
    public function toOptionArray($isMultiselect=false)
    {
        // Default values
        $array = array(
                       array("label"=>Mage::helper('adminhtml')->__('--Ingen lister fundet--'), "value"=>''),
                       );

        $conf_values = Mage::getStoreConfig('ubisync',Mage::app()->getRequest()->getParam('store'));

        $credentials = $conf_values["credentials"];

        if(is_null($credentials["ubivox_username"]) || is_null($credentials["ubivox_password"]) || is_null($credentials["ubivox_url"])) {
            return $array;
        }
        
        try {
            $http = new Zend_Http_Client($credentials["ubivox_url"], array('keepalive'=>true));
            $http->setAuth($credentials["ubivox_username"], $credentials["ubivox_password"], Zend_Http_Client::AUTH_BASIC);

            $client = new Zend_XmlRpc_Client($credentials["ubivox_url"], $http);
            $response = $client->call('ubivox.get_maillists');
        } catch(Exception $e) {
            return $array;
        }

        if(!count($response)) {
        
            return array(
                         array("label"=>Mage::helper('adminhtml')->__('--Ingen lister fundet--'), "value"=>''),
                         );
        } else {
            $array = array(
                         array("label"=>Mage::helper('adminhtml')->__('--Please Select--'), "value"=>''),
                         );
            foreach($response as $list) {
                array_push($array, array("label"=>$list["title"], "value"=>$list["id"]));
            }
            return $array;
        }
    }
}
?>