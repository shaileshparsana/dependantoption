<?php

  //class Ubivox_Ubisync_IndexController extends Mage_Core_Controller_Front_Action# Mage_Adminhtml_Newsletter_SubscriberController

class Ubivox_Ubisync_IndexController extends Mage_Adminhtml_Controller_Action
{
	public function indexAction()
        {
            
            $collectionarray = Mage::getResourceModel('newsletter/subscriber_collection')
                ->showStoreInfo()
                ->showCustomerInfo()
                ->useOnlySubscribed()
                ->toArray();
                      
            $status = "";

            $this->loadLayout();
            $block = $this->getLayout()->createBlock('ubisync/helloWorld');
            
            try {

                $conf_values   = Mage::getStoreConfig('ubisync');
                $credentials   = $conf_values["credentials"];

                $username      = $credentials["ubivox_username"];
                $password      = $credentials["ubivox_password"];
                $url           = $credentials["ubivox_url"];
                
                $data = "";
                /*
                $keys = array_keys($collectionarray["items"][0]);
                unset($keys[array_search("subscriber_email", $keys)]);

                // Create first line
                function wrappling($x) {
                    return "\"".$x."\"";
                }
                function appenddata($x) {
                    return "\"Data: ".$x."\"";
                }
                
                $data = wrappling("email").";".implode(";",array_map("appenddata", $keys))."\n";

                foreach($collectionarray["items"] as $subscriber) {
                    $data .= wrappling($subscriber["subscriber_email"]).";";
                    foreach($keys as $key) {
                        $data .= wrappling($subscriber[$key]).";";
                    }
                    $data = substr($data,0,-1);
                    $data .= "\n";
                }
                */
                $data = "email\n";
                foreach($collectionarray["items"] as $subscriber) {
                    $data .= $subscriber["subscriber_email"]."\n";
                }

                $filename = "mgUpload-".date("Y-m-d-H-i-s").".csv";


                $http = new Zend_Http_Client($url, array('keepalive'=>true));
                $http->setAuth($username, $password, Zend_Http_Client::AUTH_BASIC);            
                $client = new Zend_XmlRpc_Client($url, $http);        

                $configuration = $conf_values["configuration"];
                $listid        = $configuration["ubivox_listid"];
                $errormail     = $configuration["ubivox_errormail"];
                $return = $client->call('ubivox.import_upload', array($filename, $data));
                    
                if($return) {
                    $status = "File: $filename, has been uploaded sucessfully.";
                }

            } catch(Zend_XmlRpc_Client_HttpException $e) {
                $status = "Error uploading file:\n".$e->getMessage();                    
            } catch(Zend_XmlRpc_Client_FaultException $e) {
                $status = "Error uploading file:\n".$e->getMessage();
            } catch(Exception $e) {
                $status = "Error uploading file:\n".$e->getMessage();
            }
                
            $_SESSION["ubivox_notify"] = $status;

            $this->getLayout()->getBlock('content')->append($block);
            $this->renderLayout();
            $this->_redirect('adminhtml/newsletter_subscriber/');
            
        }              
}

